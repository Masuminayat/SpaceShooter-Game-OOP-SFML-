#pragma once
#include "Enemy.h"

// Advanced Enemy Classes
class MonsterEnemy : public Enemy {
private:
	sf::Clock movementTimer;
	bool movingRight;
	float originalX;

public:
	MonsterEnemy(float x, float y, int level)
		: Enemy(x, y, EnemyType::MONSTER, level), movingRight(true), originalX(x) {
		speed = ENEMY_SPEED * 0.5f; // Slower movement
	}

	void update(float deltaTime) override {
		Enemy::update(deltaTime);

		// Move left and right
		if (movingRight) {
			position.x += speed * deltaTime;
			if (position.x > originalX + 100) {
				movingRight = false;
			}
		}
		else {
			position.x -= speed * deltaTime;
			if (position.x < originalX - 100) {
				movingRight = true;
			}
		}

		sprite.setPosition(position);
	}

	std::vector<std::unique_ptr<Bullet>> fire(const sf::Vector2f& playerPos) override {
		std::vector<std::unique_ptr<Bullet>> bullets;

		if (bombTimer.getElapsedTime().asSeconds() >= bombInterval) {
			bombTimer.restart();

			// Fire lightning beam towards player
			sf::Vector2f direction = playerPos - position;
			float length = std::sqrt(direction.x * direction.x + direction.y * direction.y);
			if (length > 0) {
				direction /= length; // Normalize
			}

			bullets.push_back(std::make_unique<Bullet>(position.x, position.y, direction));
		}

		return bullets;
	}
};