#pragma once
#include <iostream>
#include <vector>
#include <memory>
#include <fstream>
#include <algorithm>
#include <random>
#include <cmath>
#include <sstream>

#include "GameObject.h"
#include "Enemy.h"
#include "Spaceship.h"
#include "Bullet.h"
#include "AddOn.h"

// Game Engine Class
class GameEngine {
private:
	sf::RenderWindow window;
	GameState currentState;
	std::unique_ptr<Spaceship> player;
	std::vector<std::unique_ptr<Enemy>> enemies;
	std::vector<std::unique_ptr<Bullet>> playerBullets;
	std::vector<std::unique_ptr<Bullet>> enemyBullets;
	std::vector<std::unique_ptr<AddOn>> addOns;

	sf::Font font;
	sf::Text scoreText, livesText, levelText;

	sf::Texture backgroundTexture; // Added for background
	sf::Sprite backgroundSprite;   // Added for background

	int currentScore;
	int currentLevel;
	int currentPhase;
	bool gameRunning;

	sf::Clock addOnSpawnTimer;
	sf::Clock specialEnemyTimer;
	std::mt19937 rng;

	std::vector<PlayerScore> highScores;
	std::string currentPlayerName;

public:
	GameEngine() : window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Space Invaders"),
		currentState(GameState::MENU), currentScore(0), currentLevel(1),
		currentPhase(1), gameRunning(true), rng(std::random_device{}()) {

		window.setFramerateLimit(60);

		// Initialize font (using default font for simplicity)
		if (!font.loadFromFile("arial.ttf")) {
			// Use default font if file not found
		}

		setupUI();
		loadHighScores();
		initializeLevel();
	}

	void setupUI() {
		scoreText.setFont(font);
		scoreText.setCharacterSize(24);
		scoreText.setFillColor(sf::Color::White);
		scoreText.setPosition(10, 10);

		livesText.setFont(font);
		livesText.setCharacterSize(24);
		livesText.setFillColor(sf::Color::White);
		livesText.setPosition(10, 40);

		levelText.setFont(font);
		levelText.setCharacterSize(24);
		levelText.setFillColor(sf::Color::White);
		levelText.setPosition(10, 70);
	}

	void initializeLevel() {
		player = std::make_unique<Spaceship>(WINDOW_WIDTH / 2, WINDOW_HEIGHT - 50);
		enemies.clear();
		playerBullets.clear();
		enemyBullets.clear();
		addOns.clear();

		// Load background texture based on level
		std::string backgroundFile;
		switch (currentLevel) {
		case 1:
			backgroundFile = "background_1.png";
			break;
		case 2:
			backgroundFile = "background_2.png";
			break;
		case 3:
			backgroundFile = "background_3.png";
			break;
		default:
			backgroundFile = "background_1.png"; // Fallback
			break;
		}

		if (!backgroundTexture.loadFromFile(backgroundFile)) {
			backgroundTexture.create(WINDOW_WIDTH, WINDOW_HEIGHT);
			sf::Image fallbackImage;
			fallbackImage.create(WINDOW_WIDTH, WINDOW_HEIGHT, sf::Color::Black);
			backgroundTexture.update(fallbackImage);
		}

		sf::Vector2u textureSize = backgroundTexture.getSize();
		float scaleX = static_cast<float>(WINDOW_WIDTH) / textureSize.x;
		float scaleY = static_cast<float>(WINDOW_HEIGHT) / textureSize.y;


		backgroundSprite.setTexture(backgroundTexture);
		backgroundSprite.setScale(scaleX, scaleY);


		backgroundSprite.setPosition(0, 0);

		createEnemyFormation();
	}

	void createEnemyFormation() {
		enemies.clear();

		// Create enemy formation based on level and phase
		int numEnemies = 5 + currentLevel * 2 + currentPhase;

		for (int i = 0; i < numEnemies; ++i) {
			float x = 100 + (i % 8) * 80;
			float y = 50 + (i / 8) * 60;

			EnemyType type = static_cast<EnemyType>(rng() % 3); // Random invader type
			enemies.push_back(std::make_unique<Enemy>(x, y, type, currentLevel));
		}
	}

	void spawnSpecialEnemy() {
		if (specialEnemyTimer.getElapsedTime().asSeconds() > 15.0f + (rng() % 10)) {
			specialEnemyTimer.restart();

			// Clear existing enemies temporarily
			enemies.clear();

			// Spawn monster or dragon
			EnemyType specialType = (rng() % 2) ? EnemyType::MONSTER : EnemyType::DRAGON;
			enemies.push_back(std::make_unique<Enemy>(WINDOW_WIDTH / 2, 100, specialType, currentLevel));
		}
	}

	void spawnAddOn() {
		if (addOnSpawnTimer.getElapsedTime().asSeconds() > 8.0f + (rng() % 5)) {
			addOnSpawnTimer.restart();

			float x = rng() % (WINDOW_WIDTH - 50) + 25;
			AddOnType type = static_cast<AddOnType>(rng() % 4);

			addOns.push_back(std::make_unique<AddOn>(x, 0, type));
		}
	}

	void handleInput() {
		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				gameRunning = false;
			}

			if (currentState == GameState::MENU && event.type == sf::Event::KeyPressed) {
				if (event.key.code == sf::Keyboard::Enter) {
					initializeLevel();
					currentState = GameState::PLAYING;
				}
				if (event.key.code == sf::Keyboard::I) {
					currentState = GameState::INSTRUCTIONS;
				}
				if (event.key.code == sf::Keyboard::H) {
					currentState = GameState::HIGH_SCORE;
				}
			}

			if (currentState == GameState::PLAYING && event.type == sf::Event::KeyPressed) {
				if (event.key.code == sf::Keyboard::P) {
					printf("Game Paused\n");
					currentState = GameState::PAUSED;
				}
			} else if (currentState == GameState::PAUSED && event.type == sf::Event::KeyPressed) {
				if (event.key.code == sf::Keyboard::P) {
					printf("Game Resume\n");
					currentState = GameState::PLAYING;
				}
			}

			if ((currentState == GameState::GAME_OVER || currentState == GameState::INSTRUCTIONS || currentState == GameState::HIGH_SCORE) && event.type == sf::Event::KeyPressed) {
				if (event.key.code == sf::Keyboard::Escape) {
					currentState = GameState::MENU;
				}
			}
		}

		// Handle continuous input for movement
		if (currentState == GameState::PLAYING && player) {
			sf::Time deltaTime = sf::seconds(1.0f / 60.0f);

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
				player->move(Direction::UP_LEFT, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
				player->move(Direction::UP_RIGHT, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
				player->move(Direction::DOWN_LEFT, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
				player->move(Direction::DOWN_RIGHT, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
				player->move(Direction::UP, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
				player->move(Direction::DOWN, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
				player->move(Direction::LEFT, deltaTime.asSeconds());
			}
			else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
				player->move(Direction::RIGHT, deltaTime.asSeconds());
			}

			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
				auto bullets = player->shoot();
				for (auto& bullet : bullets) {
					playerBullets.push_back(std::move(bullet));
				}
			}
		}
	}

	void update() {
		if (currentState != GameState::PLAYING) return;

		sf::Time deltaTime = sf::seconds(1.0f / 60.0f);

		// Update player
		if (player) {
			player->update(deltaTime.asSeconds());
		}

		// Update bullets
		for (auto& bullet : playerBullets) {
			bullet->update(deltaTime.asSeconds());
		}
		for (auto& bullet : enemyBullets) {
			bullet->update(deltaTime.asSeconds());
		}

		// Update enemies
		for (auto& enemy : enemies) {
			enemy->update(deltaTime.asSeconds());

			auto bullets = enemy->fire(player->getPosition());
			for (auto& bullet : bullets) {
				enemyBullets.push_back(std::move(bullet));
			}
		}

		// Update add-ons
		for (auto& addon : addOns) {
			addon->update(deltaTime.asSeconds());
		}

		// Spawn special enemies and add-ons
		spawnSpecialEnemy();
		spawnAddOn();

		// Check collisions
		checkCollisions();

		// Remove inactive objects
		removeInactiveObjects();

		// Check level completion
		if (enemies.empty()) {
			nextPhase();
		}

		// Check game over
		if (player && player->getLives() <= 0) {
			currentState = GameState::GAME_OVER;
			saveScore();
		}

		// Update UI
		updateUI();
	}

	void checkCollisions() {
		if (!player) return;

		// Player bullets vs enemies
		for (auto& bullet : playerBullets) {
			if (!bullet->isActive()) continue;

			for (auto& enemy : enemies) {
				if (!enemy->isActive()) continue;

				if (bullet->intersects(*enemy)) {
					bullet->setActive(false);
					enemy->setActive(false);
					currentScore += enemy->getScoreValue();

					// Fire bullets destroy multiple enemies
					if (bullet->isFireBullet()) {
						// Continue to destroy more enemies in path
					}
				}
			}
		}

		// Enemy bullets vs player
		for (auto& bullet : enemyBullets) {
			if (!bullet->isActive()) continue;

			if (bullet->intersects(*player)) {
				bullet->setActive(false);
				player->takeDamage();
			}
		}

		// Player vs add-ons
		for (auto& addon : addOns) {
			if (!addon->isActive()) continue;

			if (addon->intersects(*player)) {
				addon->setActive(false);

				switch (addon->getType()) {
				case AddOnType::POWER_UP:
					player->activatePowerUp();
					break;
				case AddOnType::FIRE:
					player->activateFire();
					break;
				case AddOnType::DANGER:
					player->takeDamage();
					break;
				case AddOnType::LIVES:
					player->addLife();
					break;
				}
			}
		}

		// Player vs enemies
		for (auto& enemy : enemies) {
			if (!enemy->isActive()) continue;

			if (enemy->intersects(*player)) {
				enemy->setActive(false);
				player->takeDamage();
			}
		}
	}

	void removeInactiveObjects() {
		playerBullets.erase(
			std::remove_if(playerBullets.begin(), playerBullets.end(),
				[](const auto& bullet) { return !bullet->isActive(); }),
			playerBullets.end()
		);

		enemyBullets.erase(
			std::remove_if(enemyBullets.begin(), enemyBullets.end(),
				[](const auto& bullet) { return !bullet->isActive(); }),
			enemyBullets.end()
		);

		enemies.erase(
			std::remove_if(enemies.begin(), enemies.end(),
				[](const auto& enemy) { return !enemy->isActive(); }),
			enemies.end()
		);

		addOns.erase(
			std::remove_if(addOns.begin(), addOns.end(),
				[](const auto& addon) { return !addon->isActive(); }),
			addOns.end()
		);
	}

	void nextPhase() {
		currentPhase++;
		if (currentPhase > 3) {
			currentLevel++;
			currentPhase = 1;

			if (currentLevel > 3) {
				// Game completed
				currentState = GameState::GAME_OVER;
				saveScore();
				return;
			}
		}

		createEnemyFormation();
	}

	void updateUI() {
		scoreText.setString("Score: " + std::to_string(currentScore));
		livesText.setString("Lives: " + std::to_string(player ? player->getLives() : 0));
		levelText.setString("Level: " + std::to_string(currentLevel) + "-" + std::to_string(currentPhase));
	}

	void render() {
		window.clear(sf::Color::Black);

		switch (currentState) {
		case GameState::MENU:
			renderMenu();
			break;
		case GameState::INSTRUCTIONS:
			renderInstructions();
			break;
		case GameState::PLAYING:
		case GameState::PAUSED:
			renderGame();
			if (currentState == GameState::PAUSED) {
				renderPauseOverlay();
			}
			break;
		case GameState::GAME_OVER:
			renderGameOver();
			break;
		case GameState::HIGH_SCORE:
			renderHighScores();
			break;
		}

		window.display();
	}

	void renderMenu() {
		sf::Text title("SPACE INVADERS", font, 48);
		title.setFillColor(sf::Color::White);
		title.setPosition(WINDOW_WIDTH / 2 - 200, 200);

		sf::Text instructions("Press ENTER to Play\nPress I for Instructions\nPress H for High Scores", font, 24);
		instructions.setFillColor(sf::Color::White);
		instructions.setPosition(WINDOW_WIDTH / 2 - 150, 350);

		window.draw(title);
		window.draw(instructions);
	}

	void renderInstructions() {
		sf::Text instructions("INSTRUCTIONS:\n\n"
			"Arrow Keys - Move Spaceship\n"
			"Space - Shoot\n"
			"P - Pause Game\n\n"
			"Avoid enemies and their bullets!\n"
			"Collect power-ups for special abilities!\n\n"
			"Press ESC to return to menu", font, 20);
		instructions.setFillColor(sf::Color::White);
		instructions.setPosition(50, 100);

		window.draw(instructions);
	}

	void renderGame() {
		window.draw(backgroundSprite);

		// Render player
		if (player) {
			player->render(window);
		}

		// Render enemies
		for (auto& enemy : enemies) {
			enemy->render(window);
		}

		// Render bullets
		for (auto& bullet : playerBullets) {
			bullet->render(window);
		}
		for (auto& bullet : enemyBullets) {
			bullet->render(window);
		}

		// Render add-ons
		for (auto& addon : addOns) {
			addon->render(window);
		}

		// Render UI
		window.draw(scoreText);
		window.draw(livesText);
		window.draw(levelText);
	}

	void renderPauseOverlay() {
		sf::RectangleShape overlay(sf::Vector2f(WINDOW_WIDTH, WINDOW_HEIGHT));
		overlay.setFillColor(sf::Color(0, 0, 0, 128));

		sf::Text pauseText("PAUSED\nPress P to Resume", font, 36);
		pauseText.setFillColor(sf::Color::White);
		pauseText.setPosition(WINDOW_WIDTH / 2 - 100, WINDOW_HEIGHT / 2 - 50);

		window.draw(overlay);
		window.draw(pauseText);
	}

	void renderGameOver() {
		sf::Text gameOverText("GAME OVER", font, 48);
		gameOverText.setFillColor(sf::Color::Red);
		gameOverText.setPosition(WINDOW_WIDTH / 2 - 150, 200);

		sf::Text finalScoreText("Final Score: " + std::to_string(currentScore), font, 24);
		finalScoreText.setFillColor(sf::Color::White);
		finalScoreText.setPosition(WINDOW_WIDTH / 2 - 100, 300);

		sf::Text restartText("Press ESC to return to menu", font, 20);
		restartText.setFillColor(sf::Color::White);
		restartText.setPosition(WINDOW_WIDTH / 2 - 120, 400);

		window.draw(gameOverText);
		window.draw(finalScoreText);
		window.draw(restartText);
	}

	void renderHighScores() {
		sf::Text title("HIGH SCORES", font, 36);
		title.setFillColor(sf::Color::White);
		title.setPosition(WINDOW_WIDTH / 2 - 120, 100);

		window.draw(title);

		for (size_t i = 0; i < std::min(size_t(10), highScores.size()); ++i) {
			sf::Text scoreEntry(std::to_string(i + 1) + ". " + highScores[i].name +
				" - " + std::to_string(highScores[i].score) +
				" [" + highScores[i].badge + "]", font, 20);
			scoreEntry.setFillColor(sf::Color::White);
			scoreEntry.setPosition(WINDOW_WIDTH / 2 - 200, 200 + i * 30);
			window.draw(scoreEntry);
		}

		sf::Text backText("Press ESC to return to menu", font, 18);
		backText.setFillColor(sf::Color::White);
		backText.setPosition(WINDOW_WIDTH / 2 - 120, 600);
		window.draw(backText);
	}

	void loadHighScores() {
		highScores.clear();
		std::ifstream file("highscores.txt");

		if (file.is_open()) {
			std::string line;
			while (std::getline(file, line)) {
				std::istringstream iss(line);
				std::string name, badge;
				int score;

				if (iss >> name >> score >> badge) {
					highScores.emplace_back(name, score, badge);
				}
			}
			file.close();
		}

		// Sort scores in descending order
		std::sort(highScores.begin(), highScores.end(),
			[](const PlayerScore& a, const PlayerScore& b) {
				return a.score > b.score;
			});

		// Assign badges to top 3 players
		for (size_t i = 0; i < std::min(size_t(3), highScores.size()); ++i) {
			switch (i) {
			case 0: highScores[i].badge = "GOLD"; break;
			case 1: highScores[i].badge = "SILVER"; break;
			case 2: highScores[i].badge = "BRONZE"; break;
			}
		}
	}

	void saveScore() {
		if (currentScore > 0) {
			// For simplicity, using a default player name
			// In a real implementation, you'd get this from user input
			std::string playerName = "PLAYER";

			highScores.emplace_back(playerName, currentScore, "");

			// Sort and limit to top 100 scores
			std::sort(highScores.begin(), highScores.end(),
				[](const PlayerScore& a, const PlayerScore& b) {
					return a.score > b.score;
				});

			if (highScores.size() > 100) {
				highScores.resize(100);
			}

			// Assign badges
			for (size_t i = 0; i < std::min(size_t(3), highScores.size()); ++i) {
				switch (i) {
				case 0: highScores[i].badge = "GOLD"; break;
				case 1: highScores[i].badge = "SILVER"; break;
				case 2: highScores[i].badge = "BRONZE"; break;
				}
			}

			// Save to file
			std::ofstream file("highscores.txt");
			if (file.is_open()) {
				for (const auto& score : highScores) {
					file << score.name << " " << score.score << " " << score.badge << "\n";
				}
				file.close();
			}
		}
	}

	void run() {
		while (gameRunning && window.isOpen()) {
			handleInput();
			update();
			render();
		}

		window.close();
	}
};