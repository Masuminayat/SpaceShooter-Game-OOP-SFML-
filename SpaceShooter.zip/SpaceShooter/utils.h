#pragma once

// Forward declarations
class GameObject;
class Spaceship;
class Enemy;
class Bullet;
class AddOn;
class GameEngine;

// Enums
enum class GameState { MENU, INSTRUCTIONS, PLAYING, PAUSED, GAME_OVER, HIGH_SCORE };
enum class EnemyType { ALPHA_INVADER, BETA_INVADER, GAMMA_INVADER, MONSTER, DRAGON };
enum class AddOnType { POWER_UP, FIRE, DANGER, LIVES };
enum class Direction { UP, DOWN, LEFT, RIGHT, UP_LEFT, UP_RIGHT, DOWN_LEFT, DOWN_RIGHT };


// Player Score Structure
struct PlayerScore {
	std::string name;
	int score;
	std::string badge;

	PlayerScore(const std::string& n = "", int s = 0, const std::string& b = "")
		: name(n), score(s), badge(b) {
	}
};

// Constants
const int WINDOW_WIDTH = 1920;
const int WINDOW_HEIGHT = 1080;
const int MAX_LIVES = 3;
const float SPACESHIP_SPEED = 300.0f;
const float BULLET_SPEED = 400.0f;
const float ENEMY_SPEED = 100.0f;
const float M_PI = 3.14159265358979323846f;


// Utility Functions
float distance(const sf::Vector2f& a, const sf::Vector2f& b) {
	return std::sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}
