#pragma once
#include "GameObject.h"

// AddOn Class
class AddOn : public GameObject {
private:
	AddOnType type;
	sf::Clock lifeTimer;
	float lifetime;

public:
	AddOn(float x, float y, AddOnType t) : GameObject(x, y), type(t), lifetime(10.0f) {
		velocity = sf::Vector2f(0, 50); // Fall down slowly

		// Load add-on texture based on type
		std::string textureFile;
		switch (type) {
		case AddOnType::POWER_UP:
			textureFile = "powerup.png";
			break;
		case AddOnType::FIRE:
			textureFile = "fire_powerup.png";
			break;
		case AddOnType::DANGER:
			textureFile = "danger.png";
			break;
		case AddOnType::LIVES:
			textureFile = "life.png";
			break;
		}

		if (!texture.loadFromFile(textureFile)) {
			// Fallback to circle shape
			sf::CircleShape shape(15);
			shape.setFillColor(sf::Color::Blue); // Default color

			sf::RenderTexture renderTexture;
			renderTexture.create(30, 30);
			renderTexture.clear(sf::Color::Transparent);
			renderTexture.draw(shape);
			renderTexture.display();

			texture = renderTexture.getTexture();
		}
		sprite.setTexture(texture);
		sprite.setPosition(position);
		sprite.setOrigin(texture.getSize().x / 2.0f, texture.getSize().y / 2.0f);
	}

	void update(float deltaTime) override {
		GameObject::update(deltaTime);

		// Deactivate if out of bounds or lifetime expired
		if (position.y > WINDOW_HEIGHT || lifeTimer.getElapsedTime().asSeconds() > lifetime) {
			active = false;
		}
	}

	AddOnType getType() const { return type; }
};
