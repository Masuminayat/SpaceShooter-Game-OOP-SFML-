#pragma once
#include "utils.h"
#include "Particle.h"
class ParticleSystem {
private:
	std::vector<Particle> particles;

public:
	void addExplosion(sf::Vector2f position, sf::Color color) {
		for (int i = 0; i < 20; ++i) {
			float angle = (2 * M_PI * i) / 20;
			sf::Vector2f velocity(std::cos(angle) * 100, std::sin(angle) * 100);
			particles.emplace_back(position, velocity, color, 1.0f);
		}
	}

	void update(float deltaTime) {
		for (auto& particle : particles) {
			particle.update(deltaTime);
		}

		// Remove dead particles
		particles.erase(
			std::remove_if(particles.begin(), particles.end(),
				[](const Particle& p) { return !p.isAlive(); }),
			particles.end()
		);
	}

	void render(sf::RenderWindow& window) {
		for (auto& particle : particles) {
			particle.render(window);
		}
	}
};