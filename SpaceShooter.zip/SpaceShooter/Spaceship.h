#pragma once
#include "GameObject.h"
// Spaceship Class
class Spaceship : public GameObject {
private:
	int lives;
	bool powerUpActive;
	bool fireActive;
	sf::Clock powerUpTimer;
	sf::Clock fireTimer;
	sf::Clock shootTimer;
	float shootInterval;

public:
	Spaceship(float x, float y) : GameObject(x, y), lives(MAX_LIVES),
		powerUpActive(false), fireActive(false), shootInterval(0.2f) {
		speed = SPACESHIP_SPEED;

		// Load spaceship texture
		if (!texture.loadFromFile("spaceship.png")) {
			// Fallback to circle shape
			sf::CircleShape shape(15);
			shape.setFillColor(sf::Color::Cyan);

			sf::RenderTexture renderTexture;
			renderTexture.create(30, 30);
			renderTexture.clear(sf::Color::Transparent);
			renderTexture.draw(shape);
			renderTexture.display();

			texture = renderTexture.getTexture();
		}
		//animation =  Animation(texture, { 64, 64 }, 5, 0.15f); // 4 frames, 150ms each
		//animation.setPosition(position);
		//animation.setOrigin(texture.getSize().x / 2.0f, texture.getSize().y / 2.0f);
		sprite.setTexture(texture);
		sprite.setPosition(position);
		sprite.setOrigin(texture.getSize().x / 2.0f, texture.getSize().y / 2.0f);
	}

	void update(float deltaTime) override {
		GameObject::update(deltaTime);

		//animation.update(deltaTime);

		// Handle wrap-around
		if (position.x < 0) position.x = WINDOW_WIDTH;
		if (position.x > WINDOW_WIDTH) position.x = 0;
		if (position.y < 0) position.y = WINDOW_HEIGHT;
		if (position.y > WINDOW_HEIGHT) position.y = 0;

		sprite.setPosition(position);

		// Handle power-up timer
		if (powerUpActive && powerUpTimer.getElapsedTime().asSeconds() > 5.0f) {
			powerUpActive = false;
		}

		// Handle fire timer
		if (fireActive && fireTimer.getElapsedTime().asSeconds() > 5.0f) {
			fireActive = false;
		}
	}

	void move(Direction dir, float deltaTime) {
		sf::Vector2f movement(0, 0);

		switch (dir) {
		case Direction::UP: movement.y = -speed; break;
		case Direction::DOWN: movement.y = speed; break;
		case Direction::LEFT: movement.x = -speed; break;
		case Direction::RIGHT: movement.x = speed; break;
		case Direction::UP_LEFT: movement = sf::Vector2f(-speed, -speed) * 0.707f; break;
		case Direction::UP_RIGHT: movement = sf::Vector2f(speed, -speed) * 0.707f; break;
		case Direction::DOWN_LEFT: movement = sf::Vector2f(-speed, speed) * 0.707f; break;
		case Direction::DOWN_RIGHT: movement = sf::Vector2f(speed, speed) * 0.707f; break;
		}

		position += movement * deltaTime;
	}

	std::vector<std::unique_ptr<Bullet>> shoot() {
		std::vector<std::unique_ptr<Bullet>> bullets;

		if (shootTimer.getElapsedTime().asSeconds() >= shootInterval) {
			shootTimer.restart();

			if (powerUpActive) {
				// Fire in 7 directions
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0, -1), fireActive));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0.5f, -1), fireActive));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(-0.5f, -1), fireActive));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(1, -0.5f), fireActive));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(-1, -0.5f), fireActive));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(1, 0), fireActive));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(-1, 0), fireActive));
			}
			else {
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0, -1), fireActive));
			}
		}

		return bullets;
	}

	void takeDamage() {
		if (!powerUpActive) {
			lives--;
			if (lives < 0) lives = 0;
		}
	}

	void activatePowerUp() {
		powerUpActive = true;
		powerUpTimer.restart();
	}

	void activateFire() {
		fireActive = true;
		fireTimer.restart();
	}

	void addLife() {
		lives++;
	}

	int getLives() const { return lives; }
	bool isPowerUpActive() const { return powerUpActive; }
	bool isFireActive() const { return fireActive; }
};
