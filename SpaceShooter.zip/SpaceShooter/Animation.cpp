#include "Animation.h"

Animation::Animation() {}

void Animation::setPosition(const sf::Vector2f& position) {
    sprite.setPosition(position);
}

void Animation::setPosition(float x, float y) {
    sprite.setPosition(x, y);
}

void Animation::setOrigin(const sf::Vector2f& origin) {
    sprite.setOrigin(origin);
}

void Animation::setOrigin(float x, float y) {
    sprite.setOrigin(x, y);
}



Animation::Animation(sf::Texture& texture, sf::Vector2i frameSize, int frameCount, float frameTime, int row, bool loop)
    : frameSize(frameSize), frameCount(frameCount), frameTime(frameTime),
    currentFrame(0), elapsedTime(0.f), currentRow(row), loop(loop) {

    sprite.setTexture(texture);
    sprite.setTextureRect(sf::IntRect(0, frameSize.y * row, frameSize.x, frameSize.y));
}

void Animation::update(float deltaTime) {
    elapsedTime += deltaTime;

    if (elapsedTime >= frameTime) {
        elapsedTime -= frameTime;
        currentFrame++;

        if (currentFrame >= frameCount) {
            currentFrame = loop ? 0 : frameCount - 1;
        }

        sprite.setTextureRect(sf::IntRect(currentFrame * frameSize.x, currentRow * frameSize.y, frameSize.x, frameSize.y));
    }
}

void Animation::setRow(int row) {
    if (currentRow != row) {
        currentRow = row;
        currentFrame = 0;
        elapsedTime = 0.f;
        sprite.setTextureRect(sf::IntRect(0, frameSize.y * row, frameSize.x, frameSize.y));
    }
}

void Animation::reset() {
    currentFrame = 0;
    elapsedTime = 0.f;
    sprite.setTextureRect(sf::IntRect(0, frameSize.y * currentRow, frameSize.x, frameSize.y));
}

sf::Sprite& Animation::getSprite() {
    return sprite;
}
