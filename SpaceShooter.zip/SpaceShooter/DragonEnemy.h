#pragma once
#include "Enemy.h"

class DragonEnemy : public Enemy {
private:
	sf::Clock lifeTimer;
	float lifetime;

public:
	DragonEnemy(float x, float y, int level)
		: Enemy(x, y, EnemyType::DRAGON, level), lifetime(5.0f) {
	}

	void update(float deltaTime) override {
		Enemy::update(deltaTime);

		// Dragon disappears after 5 seconds
		if (lifeTimer.getElapsedTime().asSeconds() > lifetime) {
			active = false;
		}
	}

	std::vector<std::unique_ptr<Bullet>> fire(const sf::Vector2f& playerPos) override {
		std::vector<std::unique_ptr<Bullet>> bullets;

		if (bombTimer.getElapsedTime().asSeconds() >= bombInterval) {
			bombTimer.restart();

			// Fire in 3 directions based on player position
			sf::Vector2f toPlayer = playerPos - position;

			// Determine which zone the player is in
			if (toPlayer.x < -50) {
				// Player is to the left
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(-0.5f, 1)));
			}
			else if (toPlayer.x > 50) {
				// Player is to the right  
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0.5f, 1)));
			}
			else {
				// Player is in the center
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0, 1)));
			}

			// Always fire some additional bullets
			bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(-0.2f, 1)));
			bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0.2f, 1)));
		}

		return bullets;
	}
};