#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "utils.h"

// Base GameObject Class
class GameObject {
protected:
	sf::Vector2f position;
	sf::Vector2f velocity;
	sf::Sprite sprite;
	sf::Texture texture;
	// Animation animation;
	bool active;
	float speed;

public:
	GameObject(float x = 0, float y = 0) : position(x, y), active(true), speed(100.0f) {}
	virtual ~GameObject() = default;

	virtual void update(float deltaTime) {
		position += velocity * deltaTime;
		sprite.setPosition(position);
	}

	virtual void render(sf::RenderWindow& window) {
		if (active) {
			window.draw(sprite);
			//window.draw(animation.getSprite());
		}
	}

	virtual sf::FloatRect getBounds() const {
		return sprite.getGlobalBounds();
	}

	sf::Vector2f getPosition() const { return position; }
	void setPosition(const sf::Vector2f& pos) {
		position = pos;
		sprite.setPosition(position);
	}

	bool isActive() const { return active; }
	void setActive(bool state) { active = state; }

	bool intersects(const GameObject& other) const {
		return getBounds().intersects(other.getBounds());
	}
};
