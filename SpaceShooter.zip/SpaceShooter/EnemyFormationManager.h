#pragma once
#include "GameObject.h"
// Enemy Formation Manager Class
class EnemyFormationManager {
private:
	int currentLevel;
	int currentPhase;

public:
	EnemyFormationManager(int level = 1, int phase = 1)
		: currentLevel(level), currentPhase(phase) {
	}

	std::vector<sf::Vector2f> getRectangleFormation(int numEnemies) {
		std::vector<sf::Vector2f> positions;
		int cols = 8;
		int rows = (numEnemies + cols - 1) / cols;

		for (int i = 0; i < numEnemies; ++i) {
			float x = 100 + (i % cols) * 80;
			float y = 50 + (i / cols) * 60;
			positions.emplace_back(x, y);
		}

		return positions;
	}

	std::vector<sf::Vector2f> getTriangleFormation(int numEnemies) {
		std::vector<sf::Vector2f> positions;
		int row = 0;
		int enemiesPlaced = 0;

		while (enemiesPlaced < numEnemies) {
			int enemiesInRow = row + 1;
			float startX = WINDOW_WIDTH / 2 - (enemiesInRow * 40);

			for (int i = 0; i < enemiesInRow && enemiesPlaced < numEnemies; ++i) {
				float x = startX + i * 80;
				float y = 50 + row * 60;
				positions.emplace_back(x, y);
				enemiesPlaced++;
			}
			row++;
		}

		return positions;
	}

	std::vector<sf::Vector2f> getCrossFormation(int numEnemies) {
		std::vector<sf::Vector2f> positions;
		int centerX = WINDOW_WIDTH / 2;
		int centerY = 200;

		// Vertical line
		for (int i = 0; i < numEnemies / 2; ++i) {
			positions.emplace_back(centerX, centerY + (i - numEnemies / 4) * 50);
		}

		// Horizontal line
		for (int i = numEnemies / 2; i < numEnemies; ++i) {
			positions.emplace_back(centerX + (i - 3 * numEnemies / 4) * 50, centerY);
		}

		return positions;
	}

	std::vector<sf::Vector2f> getCircleFormation(int numEnemies) {
		std::vector<sf::Vector2f> positions;
		float centerX = WINDOW_WIDTH / 2;
		float centerY = 200;
		float radius = 120;

		for (int i = 0; i < numEnemies; ++i) {
			float angle = (2 * M_PI * i) / numEnemies;
			float x = centerX + radius * std::cos(angle);
			float y = centerY + radius * std::sin(angle);
			positions.emplace_back(x, y);
		}

		return positions;
	}

	std::vector<sf::Vector2f> getDiamondFormation(int numEnemies) {
		std::vector<sf::Vector2f> positions;
		int centerX = WINDOW_WIDTH / 2;
		int centerY = 200;

		// Diamond shape - top, left, right, bottom
		int quarter = numEnemies / 4;

		// Top point
		for (int i = 0; i < quarter; ++i) {
			positions.emplace_back(centerX, centerY - 100 + i * 25);
		}

		// Left side
		for (int i = 0; i < quarter; ++i) {
			positions.emplace_back(centerX - 100 + i * 25, centerY);
		}

		// Right side
		for (int i = 0; i < quarter; ++i) {
			positions.emplace_back(centerX + i * 25, centerY);
		}

		// Bottom point
		for (int i = quarter * 3; i < numEnemies; ++i) {
			positions.emplace_back(centerX, centerY + (i - quarter * 3) * 25);
		}

		return positions;
	}

	std::vector<sf::Vector2f> getHeartFormation(int numEnemies) {
		std::vector<sf::Vector2f> positions;
		float centerX = WINDOW_WIDTH / 2;
		float centerY = 200;

		// Simple heart approximation using parametric equations
		for (int i = 0; i < numEnemies; ++i) {
			float t = (2 * M_PI * i) / numEnemies;
			float x = centerX + 50 * (16 * std::pow(std::sin(t), 3));
			float y = centerY - 50 * (13 * std::cos(t) - 5 * std::cos(2 * t) - 2 * std::cos(3 * t) - std::cos(4 * t));
			positions.emplace_back(x / 16, y / 16 + centerY);
		}

		return positions;
	}

	std::vector<sf::Vector2f> getFormationForLevel(int level, int phase, int numEnemies) {
		switch (level) {
		case 1:
			switch (phase) {
			case 1: return getRectangleFormation(numEnemies);
			case 2: return getTriangleFormation(numEnemies);
			case 3: return getCrossFormation(numEnemies);
			default: return getRectangleFormation(numEnemies);
			}
		case 2:
			switch (phase) {
			case 1: return getCircleFormation(numEnemies);
			case 2: return getDiamondFormation(numEnemies);
			case 3: return getHeartFormation(numEnemies);
			default: return getCircleFormation(numEnemies);
			}
		case 3:
			// Combination of all formations
			switch (phase) {
			case 1: return getRectangleFormation(numEnemies);
			case 2: return getCircleFormation(numEnemies);
			case 3: return getHeartFormation(numEnemies);
			default: return getRectangleFormation(numEnemies);
			}
		default:
			return getRectangleFormation(numEnemies);
		}
	}
};