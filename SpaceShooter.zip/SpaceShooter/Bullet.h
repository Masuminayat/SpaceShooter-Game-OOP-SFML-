#pragma once
#include "GameObject.h"

// Bullet Class
class Bullet : public GameObject {
private:
	bool isFire;
	sf::Vector2f direction;

public:
	Bullet(float x, float y, sf::Vector2f dir, bool fire = false)
		: GameObject(x, y), isFire(fire), direction(dir) {
		speed = BULLET_SPEED;
		velocity = direction * speed;

		// Load bullet texture
		if (!texture.loadFromFile(isFire ? "fire_bullet.png" : "bullet.png")) {
			// Fallback to simple shape if texture fails to load
			sf::RectangleShape bulletShape(sf::Vector2f(3, 8));
			bulletShape.setFillColor(isFire ? sf::Color::Red : sf::Color::Yellow);

			sf::RenderTexture renderTexture;
			renderTexture.create(3, 8);
			renderTexture.clear(sf::Color::Transparent);
			renderTexture.draw(bulletShape);
			renderTexture.display();

			texture = renderTexture.getTexture();
		}
		sprite.setTexture(texture);
		sprite.setPosition(position);
		// Adjust sprite origin to center
		sprite.setOrigin(texture.getSize().x / 2.0f, texture.getSize().y / 2.0f);
		float angle = std::atan2(direction.y, direction.x) * 180.f / 3.14159265f;
		sprite.setRotation(angle + 90.0f);
	}

	void update(float deltaTime) override {
		GameObject::update(deltaTime);

		// Deactivate if out of bounds
		if (position.x < 0 || position.x > WINDOW_WIDTH ||
			position.y < 0 || position.y > WINDOW_HEIGHT) {
			active = false;
		}
	}

	bool isFireBullet() const { return isFire; }
};