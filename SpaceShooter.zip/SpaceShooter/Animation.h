#pragma once
#include <SFML/Graphics.hpp>

class Animation {
public:
    Animation(sf::Texture& texture, sf::Vector2i frameSize, int frameCount, float frameTime, int row = 0, bool loop = true);
    Animation();
    void update(float deltaTime);
    void setRow(int row);
    void reset();
    sf::Sprite& getSprite();
    void setPosition(const sf::Vector2f& position);
    void setPosition(float x, float y);
    void setOrigin(const sf::Vector2f& origin);
    void setOrigin(float x, float y);


private:
    sf::Sprite sprite;
    sf::Vector2i frameSize;
    int frameCount;
    float frameTime;
    int currentFrame;
    float elapsedTime;
    int currentRow;
    bool loop;
};
