#pragma once
#include<SFML/Graphics.hpp>
// Particle System for Visual Effects
class Particle {
private:
	sf::Vector2f position;
	sf::Vector2f velocity;
	sf::Color color;
	float lifetime;
	float age;

public:
	Particle(sf::Vector2f pos, sf::Vector2f vel, sf::Color col, float life)
		: position(pos), velocity(vel), color(col), lifetime(life), age(0) {
	}

	void update(float deltaTime) {
		age += deltaTime;
		position += velocity * deltaTime;

		// Fade out over time
		float alpha = (1.0f - age / lifetime) * 255;
		color.a = static_cast<sf::Uint8>(std::max(0.0f, alpha));
	}

	void render(sf::RenderWindow& window) {
		sf::CircleShape particle(2);
		particle.setFillColor(color);
		particle.setPosition(position);
		window.draw(particle);
	}

	bool isAlive() const {
		return age < lifetime;
	}
};
