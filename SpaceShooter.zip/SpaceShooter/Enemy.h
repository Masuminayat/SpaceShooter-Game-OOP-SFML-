#pragma once
#include "GameObject.h"
// Enemy Base Class
class Enemy : public GameObject {
protected:
	EnemyType type;
	int scoreValue;
	sf::Clock bombTimer;
	float bombInterval;
	int level;

public:
	Enemy(float x, float y, EnemyType t, int lvl)
		: GameObject(x, y), type(t), level(lvl) {
		switch (type) {
		case EnemyType::ALPHA_INVADER:
			scoreValue = 10 * level;
			bombInterval = 5.0f;
			break;
		case EnemyType::BETA_INVADER:
			scoreValue = 20 * level;
			bombInterval = 3.0f;
			break;
		case EnemyType::GAMMA_INVADER:
			scoreValue = 30 * level;
			bombInterval = 2.0f;
			break;
		case EnemyType::MONSTER:
			scoreValue = 40;
			bombInterval = 2.0f;
			break;
		case EnemyType::DRAGON:
			scoreValue = 50;
			bombInterval = 1.0f;
			break;
		}
		createSprite();
	}

	virtual void createSprite() {
		std::string textureFile;
		switch (type) {
		case EnemyType::ALPHA_INVADER:
			textureFile = "alpha.png";
			break;
		case EnemyType::BETA_INVADER:
			textureFile = "beta.png";
			break;
		case EnemyType::GAMMA_INVADER:
			textureFile = "gamma.png";
			break;
		case EnemyType::MONSTER:
			textureFile = "monster.png";
			break;
		case EnemyType::DRAGON:
			textureFile = "dragon.png";
			break;
		}

		if (!texture.loadFromFile(textureFile)) {
			// Fallback to rectangle shape
			sf::RectangleShape shape(sf::Vector2f(30, 30));
			shape.setFillColor(sf::Color::White); // Default color

			if (type == EnemyType::MONSTER) {
				shape.setSize(sf::Vector2f(50, 40));
			}
			else if (type == EnemyType::DRAGON) {
				shape.setSize(sf::Vector2f(60, 50));
			}

			sf::RenderTexture renderTexture;
			renderTexture.create(shape.getSize().x, shape.getSize().y);
			renderTexture.clear(sf::Color::Transparent);
			renderTexture.draw(shape);
			renderTexture.display();

			texture = renderTexture.getTexture();
		}
		sprite.setTexture(texture);
		sprite.setPosition(position);
		sprite.setOrigin(texture.getSize().x / 2.0f, texture.getSize().y / 2.0f);
	}

	virtual std::vector<std::unique_ptr<Bullet>> fire(const sf::Vector2f& playerPos) {
		std::vector<std::unique_ptr<Bullet>> bullets;

		if (bombTimer.getElapsedTime().asSeconds() >= bombInterval) {
			bombTimer.restart();

			if (type == EnemyType::DRAGON) {
				// Dragon fires in 3 directions based on player position
				sf::Vector2f toPlayer = playerPos - position;

				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0, 1)));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0.5f, 1)));
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(-0.5f, 1)));
			}
			else if (type == EnemyType::MONSTER) {
				// Monster fires lightning beam
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0, 1)));
			}
			else {
				// Regular invaders fire single bullet
				bullets.push_back(std::make_unique<Bullet>(position.x, position.y, sf::Vector2f(0, 1)));
			}
		}

		return bullets;
	}

	int getScoreValue() const { return scoreValue; }
	EnemyType getType() const { return type; }
};
